'use client';

import Input from '@/components/common/Input';
import { useRouter, useParams } from 'next/navigation';
import { useEffect, useState, useCallback, useMemo } from 'react';
import { getSubjects, getAges } from '@/api/academyApi';
import { createClass } from '@/api/classApi';
import { toast } from 'sonner';
import styles from './ClassRegisterPage.module.css';
import Button from '@/components/common/Button';
import Select from '@/components/common/Select';

const DAYS = [
  { id: 'monday', label: '월' },
  { id: 'tuesday', label: '화' },
  { id: 'wednesday', label: '수' },
  { id: 'thursday', label: '목' },
  { id: 'friday', label: '금' },
  { id: 'saturday', label: '토' },
  { id: 'sunday', label: '일' },
];

const formatPrice = (val: string) => {
  if (!val) return '';
  const num = val.replace(/\D/g, '');
  if (!num) return '';
  return new Intl.NumberFormat().format(Number(num));
};

export default function ClassRegisterPage() {
  const router = useRouter();
  const { academyId } = useParams();

  const [ageOptions, setAgeOptions] = useState<
    { id: number; ageCode: string }[]
  >([]);
  const [subjectOptions, setSubjectOptions] = useState<
    { id: number; detailSubject: string }[]
  >([]);

  const [selectedAgeId, setSelectedAgeId] = useState<number | null>(null);
  const [selectedSubjectId, setSelectedSubjectId] = useState<number | null>(null);

  const [formData, setFormData] = useState({
    className: '',
    startTime: '09:00',
    endTime: '18:00',
    monday: false,
    tuesday: false,
    wednesday: false,
    thursday: false,
    friday: false,
    saturday: false,
    sunday: false,
    price: '',
  });

  const [isLoadingOptions, setIsLoadingOptions] = useState(true);

  useEffect(() => {
    const fetchAgesSubjects = async () => {
      try {
        setIsLoadingOptions(true);
        const [subData, ageData] = await Promise.all([
          getSubjects(academyId as string),
          getAges(academyId as string),
        ]);
        setSubjectOptions(subData || []);
        setAgeOptions(ageData || []);
      } catch (err) {
        console.error('과목 로딩 실패:', err);
      } finally {
        setIsLoadingOptions(false);
      }
    };

    if (academyId) fetchAgesSubjects();
  }, [academyId]);


  const handleChange = useCallback((
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value, type } = e.target;

    if (type === 'checkbox') {
      const { checked } = e.target as HTMLInputElement;
      setFormData((prev) => ({ ...prev, [name]: checked }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  }, []);

  const handlePriceChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const rawValue = e.target.value.replace(/\D/g, '');
    setFormData(prev => ({ ...prev, price: rawValue }));
  }, []);

  const handleAgeChange = useCallback((val: any) => {
    setSelectedAgeId(Number(val));
  }, []);

  const handleSubjectChange = useCallback((val: any) => {
    setSelectedSubjectId(Number(val));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const hasDay = DAYS.some((day) => (formData as any)[day.id]);
    if (!hasDay) {
      toast.error('수업 요일을 최소 하나 이상 선택해주세요.');
      return;
    }

    if (!selectedAgeId || !selectedSubjectId) {
      toast.error('학년과 과목을 선택해주세요.');
      return;
    }

    try {
      await createClass(academyId as string, {
        ...formData,
        ageId: selectedAgeId,
        subjectId: selectedSubjectId,
      });

      toast.success('클래스가 성공적으로 등록되었습니다.');
      router.push(`/academy/${academyId}`);
    } catch (err) {
      toast.error('등록 중 오류가 발생했습니다.');
    }
  };

  const ageSelectOptions = useMemo(() => 
    ageOptions.map((a) => ({ label: a.ageCode, value: a.id })),
    [ageOptions]
  );

  const subjectSelectOptions = useMemo(() => 
    subjectOptions.map((s) => ({ label: s.detailSubject, value: s.id })),
    [subjectOptions]
  );

  const formattedPrice = useMemo(() => formatPrice(formData.price), [formData.price]);

  return (
    <div className={styles.container}>
      <header className={styles.header}>
        <button onClick={() => router.back()} className={styles.backBtn}>
          &lt; 이전
        </button>
        <h1>신규 클래스 등록</h1>
      </header>

      <form onSubmit={handleSubmit} className={styles.form}>
        <Input
          label="클래스 명"
          name="className"
          value={formData.className}
          onChange={handleChange}
          placeholder="ex) 초등 수학 심화반"
          required
        />

        <div className={styles.inputGroup}>
          <Select
            label="학년 구분"
            options={ageSelectOptions}
            value={selectedAgeId}
            onChange={handleAgeChange}
            placeholder={isLoadingOptions ? "로딩 중..." : "학년을 선택하세요"}
          />
        </div>

        <div className={styles.inputGroup}>
          <Select
            label="과목"
            options={subjectSelectOptions}
            value={selectedSubjectId}
            onChange={handleSubjectChange}
            placeholder={isLoadingOptions ? "로딩 중..." : "과목을 선택하세요"}
          />
        </div>

        <div className={styles.inputGroup}>
          <label className={styles.customLabel}>수업 요일</label>
          <div className={styles.dayContainer}>
            {DAYS.map((day) => (
              <label key={day.id} className={styles.dayItem}>
                <input
                  type="checkbox"
                  name={day.id}
                  checked={(formData as any)[day.id]}
                  onChange={handleChange}
                />
                <span>{day.label}</span>
              </label>
            ))}
          </div>
        </div>

        <div className={styles.row}>
          <Input
            label="시작 시간"
            type="time"
            name="startTime"
            value={formData.startTime}
            onChange={handleChange}
          />
          <Input
            label="종료 시간"
            type="time"
            name="endTime"
            value={formData.endTime}
            onChange={handleChange}
          />
        </div>

        <Input
          label="월 수업비"
          type="text"
          name="price"
          value={formattedPrice}
          onChange={handlePriceChange}
          placeholder="ex) 200,000"
        />

        <div className={styles.buttonWrapper}>
          <Button variant="primary" type="submit">
            등록하기
          </Button>
        </div>
      </form>
    </div>
  );
}
